_(2015年1月1日)语盒、语电通作者已经停止开发此项目了,详见[这里](http://bbs.yuchs.com/read.php?tid=2653)，请大家多多支持BB10_

_(2015年3月14日)随着Google Code的关闭，语盒项目整体迁移到Github，虽然已经不开发了，至少不能让他没有了。所有的wiki文档的格式完全变了，导致阅读有些困难，我只手动格式化了这个页面，如果其他文档页面格式混乱，还请海涵_

# 语盒官方网站 www.yuchs.com
![http://www.yuchs.com](http://image.yuchs.com/www/logo.gif)<br />
    语盒官方服务器推出[邀请机制](https://github.com/yuchting/yuchbox/wiki/Invite_Mechanism)，每个账户有10个邀请数量，增加自己的免费时间！语盒新手、自架服务器必看[FAQ](https://github.com/yuchting/yuchbox/wiki/FAQ)。

  语盒开发者最新发布来电显示软件——<b>语电通（YuchCaller）</b>，用于显示来电归属地，<b>完全免费</b>，详细请访问[语电通开源项目主页](https://github.com/yuchting/yuchcaller)。

# 下载
  [版本更新内容](https://github.com/yuchting/yuchbox/wiki/Promote_list) | [安装、更新方法](https://github.com/yuchting/yuchbox/wiki/Update_Method) | [历史版本下载](https://github.com/yuchting/yuchbox/releases)
  
  * 服务器：（自架服务器需要下载）
[服务器-JRE环境(3.0M)](https://github.com/yuchting/yuchbox/releases/download/1.16.2085/yuchsbox_server_1.16.2085.1.zip) | <b>1.16.2085.1</b> 版本(支持Windows、GNU/Linux、MacOS) <b>需要[下载JRE](http://www.oracle.com/technetwork/java/javase/downloads/index.html)</b>

  * 客户端(<b>OTA安装</b>，请手机浏览器访问 [http://ota.yuchs.com](http://ota.yuchs.com/))。<font color='red'>（旧版本更新需要<b>卸载之前的1.12.1833版本</b>；自架服务器的朋友服务器程序需要更新到最新）</font>
<table> 
   <tbody>
    <tr>
     <td><a href="https://github.com/yuchting/yuchbox/releases/download/1.16.2085/yuchdroid_1.16.2085.apk">Android客户端</a> </td>
     <td> 1.16.2085 Android 安卓版本 Android系统1.6 以上</td>
    </tr> 
    <tr>
     <td><a href="https://github.com/yuchting/yuchbox/releases/download/1.16.2085/yuchbox_1.16.2085.2_for_4.2os.zip">黑莓客户端-4.2系统</a> </td>
     <td> 1.16.2085 版本 支持黑莓<b>4.2</b>系统（不支持HTML附件、Weibo/IM桌面提醒）</td>
    </tr> 
    <tr>
     <td><a href="https://github.com/yuchting/yuchbox/releases/download/1.16.2085/yuchbox_1.16.2085.2_for_4.5os.zip">黑莓客户端-4.5系统</a> </td>
     <td> 1.16.2085 版本 支持黑莓<b>4.5</b>系统（不支持Weibo/IM桌面提醒）</td>
    </tr> 
    <tr>
     <td><a href="https://github.com/yuchting/yuchbox/releases/download/1.16.2085/yuchbox_1.16.2085.2_for_4.6os.zip">黑莓客户端-4.6系统</a> </td>
     <td> 1.16.2085 版本 支持黑莓<b>4.6</b>系统</td>
    </tr> 
    <tr>
     <td><a href="https://github.com/yuchting/yuchbox/releases/download/1.16.2085/yuchbox_1.16.2085.2_for_4.7os.zip">黑莓客户端-4.7系统</a> </td>
     <td> 1.16.2085 版本 支持黑莓<b>4.7</b>系统</td>
    </tr> 
    <tr>
     <td><a href="https://github.com/yuchting/yuchbox/releases/download/1.16.2085/yuchbox_1.16.2085.2_for_5.0os.zip">黑莓客户端-5.0系统</a> </td>
     <td> 1.16.2085 版本 支持黑莓<b>5.0</b>系统</td>
    </tr> 
    <tr>
     <td><a href="https://github.com/yuchting/yuchbox/releases/download/1.16.2085/yuchbox_1.16.2085.2_for_6.0os.zip">黑莓客户端-6.0+系统</a> </td>
     <td> 1.16.2085 版本 支持黑莓<b>6.0+</b>系统 </td>
    </tr> 
   </tbody> 
  </table>

  * 客户端Mod版，请手机浏览器访问 [http://ota.yuchs.com](http://ota.yuchs.com/))。 感谢热心莓友<b>[三叶莓](http://weibo.com/berrysun2012)</b>（886055#gmail.com）友情制作[IM模块](https://github.com/yuchting/yuchbox/wiki/YuchBerry_IM)、[Weibo模块](https://github.com/yuchting/yuchbox/wiki/YuchBerry_Weibo)的[新皮肤Mod版本的语盒](https://github.com/yuchting/yuchbox/wiki/BBM_Skin_IM):<br>
<table class="wikitable">
   <tbody>
    <tr>
     <td><a href="https://github.com/yuchting/yuchbox/releases/download/1.16.2085/yuchbox_1.16.2085_BBM_Mod_for_5.0os.zip">BBM皮肤-黑莓5.0系统</a> </td>
     <td> 语盒<b>1.16.2085</b> Mod版本 IM模块BBM皮肤、Weibo新皮肤Mod版本</td>
    </tr> 
    <tr>
     <td><a href="https://github.com/yuchting/yuchbox/releases/download/1.16.2085/yuchbox_1.16.2085.1_BBM_Mod_for_6.0os.zip">BBM皮肤-黑莓6.0+系统</a> </td>
     <td> 语盒<b>1.16.2085</b> Mod版本 IM模块BBM皮肤、Weibo新皮肤Mod版本</td>
    </tr> 
    <tr>
     <td><a href="https://github.com/yuchting/yuchbox/releases/download/1.16.2085/yuchbox_1.16.2085_Girl_Mod_for_5.0os.zip">粉色女生版-黑莓5.0系统</a> </td>
     <td> 语盒<b>1.16.2085</b> Mod版本 IM模块、Weibo新皮肤Mod版本（粉色女生版），含浪小花表情全套</td>
    </tr> 
    <tr>
     <td><a href="https://github.com/yuchting/yuchbox/releases/download/1.16.2085/yuchbox_1.16.2085.1_Girl_Mod_for_6.0os.zip">粉色女生版-黑莓6.0+系统</a> </td>
     <td> 语盒<b>1.16.2085</b> Mod版本 IM模块、Weibo新皮肤Mod版本（粉色女生版），含浪小花表情全套</td>
    </tr> 
    <tr>
     <td><a href="https://github.com/yuchting/yuchbox/releases/download/1.16.2085/yuchsbox_1.11.1633_mod_6_for_5.0os.zip">G+ 皮肤</a> </td>
     <td> 1.11.1633 版本 支持黑莓<b>5.0（含）以上</b>系统 IM模块 G+ 皮肤、Weibo新皮肤Mod版本</td>
    </tr> 
    <tr>
     <td><a href="https://github.com/yuchting/yuchbox/releases/download/1.16.2085/yuchsbox_1.11.1633_mod_7_for_5.0os.zip">炫彩皮肤</a> </td>
     <td> 1.11.1633 版本 支持黑莓<b>5.0（含）以上</b>系统 IM模块炫彩皮肤、Weibo新皮肤Mod版本，含浪小花表情全套</td>
    </tr> 
   </tbody>
  </table>

#  赞助 
  官方服务器的收入只能支持基本的服务器租用费用，如果您仍然能够慷慨解囊赞助这个开源项目，我们会感谢您的无私，并[铭记在心](https://github.com/yuchting/yuchbox/wiki/Thanks_sheet)，详情请访问[这里](https://github.com/yuchting/yuchbox/wiki/Sponsor_yuchberry)。
