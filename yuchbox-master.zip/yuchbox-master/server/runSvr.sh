#!/bin/sh
java -jar svr.jar console
