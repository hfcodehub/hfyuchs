#!/bin/sh
javaw -jar svr.jar frame &
