package com.mime.qweibo;

//yuchberry added @ 2011-5-27
//
public class QUserTag{
	/*
	Tag:
		Id:个人标签ID
		Name:标签名
	*/
	public int 	m_tagId;
	public String	m_tagName = "";
}
