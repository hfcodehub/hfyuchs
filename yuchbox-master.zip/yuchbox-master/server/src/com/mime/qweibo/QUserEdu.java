package com.mime.qweibo;

//yuchberry added @ 2011-5-27
//
public class QUserEdu {
	/*
	Id:学历记录ID
		Year 入学年
		Schoolid 学校ID
		Departmentid 院系ID
		Level 学历级别
	*/
	public int m_id;
	public int m_enterYear;
	public int	m_schoolId;
	public	int	m_departmentId;
	public	int	m_enterLevel;
}
