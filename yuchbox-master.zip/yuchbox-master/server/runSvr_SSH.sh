#!/bin/sh
nohup java -jar svr.jar &
